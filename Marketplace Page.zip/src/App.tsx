import { useState } from "react";
import { LoginPage } from "./components/LoginPage";
import { StorePage } from "./components/StorePage";
import { CartProvider } from "./contexts/CartContext";
import { AppProvider } from "./contexts/AppContext";
import { Toaster } from "./components/ui/sonner";

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  const handleLogin = () => {
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
  };

  if (!isAuthenticated) {
    return <LoginPage onLogin={handleLogin} />;
  }

  return (
    <AppProvider>
      <CartProvider>
        <StorePage onLogout={handleLogout} />
        <Toaster />
      </CartProvider>
    </AppProvider>
  );
}